/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javaprojectmanagementsystem;

import student.Student;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author User
 */
public class Lecturer extends User {
    private String school;
    private boolean isProjectManager;
    private List<Student> supervisees;
    
    public Lecturer(String id, String name, String email, String school) {
        super(id, name, email);
        this.school = school;
        this.isProjectManager = false;
        this.supervisees = new ArrayList<>();
    }
    
    public void addSupervisee(Student student) {
        supervisees.add(student);
    }
    
    public void viewPresentationRequests() {
//        Presentation Manage Page
    }
    
    public void confirmPresentationDate(Student student, String date) {
//        student.setPresentationDate(date);
    }
    
    public void viewSuperviseeList() {
        for (Student student : supervisees) {
            
        }
    }
}
